a. Name, CSU ID, and Assignment number

Lakiel Wade
2601283
Assignment 2
------------------------------------------
b. Brief description of the assignment

The program will keep prompting user to input a number until a 0 is given or 10 numbers are given, whichever comes first. The program prints a sorted list of the numbers given by the user, in increasing order. If no number is
given by the user, the program prints a message “No number is given.” and exits.
--------------------------------------------
c. Compiling instruction

compile ->  gcc Assign2.c QuickSort.c
run -> ./a.out
-------------------------------------------
d. A sample test run

lakiel@Six:~/Documents/cis340/2nd time/Assign2/wadeLakiel$ ./Assign2 
Enter value or enter 0 to quit: -65
Enter value or enter 0 to quit: 5
Enter value or enter 0 to quit: 54
Enter value or enter 0 to quit: 15
Enter value or enter 0 to quit: -5
Enter value or enter 0 to quit: -0
element in array index 0: -65
element in array index 1: -5
element in array index 2: 5
element in array index 3: 15
element in array index 4: 54


